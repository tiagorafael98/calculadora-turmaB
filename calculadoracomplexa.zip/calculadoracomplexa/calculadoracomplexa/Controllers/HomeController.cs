﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace calculadoracomplexa.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        [HttpGet]  //facultativo, pq por defeito é sempre este o verbo utilizado
        public ActionResult Index() {
            //preparar os primeiros valores da calculadora
            //ou ViewBag.Visor="0" é indiferente (neste caso)
            ViewBag.Visor = 0;
            Session["operador"] = "";
            return View();
        }

        // POST: Home
        //método para responder ao post
        [HttpPost]
        //ao duplicarmos o metodo, n podemos esquecer da "chave" httpPost
        //string bt - ler o valoro do botão
        public ActionResult Index(string bt, string visor) {

            // determinar a ação a executar
            switch(bt)
            {
                case "1":
                case "2":
                case "3":
                case "4":
                case "5":
                case "6":
                case "7":
                case "8":
                case "9":
                case "0":
                    //if valor no visor ou visor=="0". string é um array de caracteres
                    //Se no visor inicial é = 0, ao clicar, substitui mas nao muda o q tá no visor
                    if (visor.Equals("0")) visor = bt;
                    //se não for, é substituido por outro numero cujo qual o botao foi clicado
                    else visor += bt;
                    break;

                case "+/-":
                    //
                    visor = Convert.ToDouble(visor) * -1 + ""; //qq + a string é uma string
                    break;

                case ",":
                    //Se o visor n tiver uma virgula, add
                    if (!visor.Contains(",")) visor += ",";

                    break;

                case "+":
                case "-":
                case "x":
                case ":":
                    //Se é a primeira vez que pressiono um operador. Se for igual a vazio, é q ele n foi selecionado
                    //Session n tem tipo, entao temos q escrever (string) antes para o definir

                    //if ((string)Session["operador"] == "")
                    if (((string)Session["operador"]).Equals("")) {
                        //preservar o valor do VISOR
                        //usando variáveis da sessão. Guardar o primeiro valor
                        Session["PrimeiroOperando"] = visor;
                        //guardar o valor do operador /variavel de sessão q guarda os operadores
                        Session["operador"] = bt;
                        //preparar o visor para uma nova introdução
                        visor = ""; //visor fica limpo
                    }
                    else
                    {
                        //agora é q se vai fazer a 'conta'
                        //obter os operandos
                        double primeiroOperando = Convert.ToDouble((string)Session["primeiroOperando"]);

                        double segundoOperando = Convert.ToDouble(visor);

                        //escolher a operação a fazer com operador anterior
                        switch ((string)Session["operador"])
                        {
                            case "+":
                                visor = primeiroOperando + segundoOperando + ""; //meter o + "" pq se for o 1º converte pra string e só dps faz a operação
                                break;

                            case "-":
                                visor = primeiroOperando - segundoOperando + "";
                                break;
                            
                            case "x":
                                visor = primeiroOperando * segundoOperando + "";
                                break;
                            case ":":
                                visor = primeiroOperando / segundoOperando + "";
                                break;
                        }
                    }

                    break;

            }

            ViewBag.Visor = visor;
            return View();
        }
    }
}